# VC Meeting OS - Deployment Guide

## Quick Deploy to Vercel (5 Minutes)

### Prerequisites
- GitHub account
- Vercel account  
- PostgreSQL database (Vercel Postgres recommended)

### Step 1: Prepare Repository

```bash
cd vc-meeting-os

# Initialize git
git init
git add .
git commit -m "Initial VC Meeting OS deployment"

# Create GitHub repo and push
gh repo create vc-meeting-os --private
git remote add origin git@github.com:YOUR_USERNAME/vc-meeting-os.git
git push -u origin main
```

### Step 2: Deploy to Vercel

#### Option A: Vercel Dashboard (Recommended)

1. Go to [vercel.com/new](https://vercel.com/new)
2. Import your GitHub repository
3. Configure project:
   - Framework Preset: **Next.js**
   - Root Directory: `./`
   - Build Command: `prisma generate && next build`
   - Output Directory: `.next`

4. Add Environment Variables (click "Environment Variables"):

```
DATABASE_URL=postgresql://...
NEXTAUTH_SECRET=(generate with: openssl rand -base64 32)
NEXTAUTH_URL=https://your-app.vercel.app
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
FIREFLIES_CLIENT_ID=...
FIREFLIES_CLIENT_SECRET=...
```

5. Click **Deploy**

#### Option B: Vercel CLI

```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Deploy
vercel

# Follow prompts to link project

# Add environment variables
vercel env add DATABASE_URL
vercel env add NEXTAUTH_SECRET
# ... add all other variables

# Redeploy
vercel --prod
```

### Step 3: Setup Database

```bash
# Set DATABASE_URL in .env.local for local setup

# Generate Prisma client
npx prisma generate

# Run migrations on production database
npx prisma migrate deploy
```

Or use Vercel Postgres:
1. Go to Storage tab in Vercel dashboard
2. Create Postgres database
3. Copy connection string
4. Add as `DATABASE_URL` environment variable
5. Redeploy

### Step 4: Configure OAuth Apps

#### Google OAuth (for Drive integration)

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create new project or select existing
3. Enable **Google Drive API**
4. Create OAuth 2.0 credentials:
   - Application type: Web application
   - Authorized redirect URIs: 
     - `https://your-app.vercel.app/api/auth/callback/google`
   - Copy Client ID and Client Secret
5. Add to Vercel environment variables

#### Fireflies OAuth

1. Contact Fireflies support for OAuth credentials
2. Provide callback URL: `https://your-app.vercel.app/api/auth/callback/fireflies`
3. Add credentials to Vercel environment variables

### Step 5: Test Deployment

1. Visit `https://your-app.vercel.app`
2. Sign up for account
3. Complete onboarding
4. Connect Fireflies and Google Drive
5. Trigger first meeting sync
6. Verify document creation in Drive

## Environment Variables Reference

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://user:pass@host/db` |
| `NEXTAUTH_SECRET` | Auth secret (32+ chars) | `openssl rand -base64 32` |
| `NEXTAUTH_URL` | Your app URL | `https://app.vercel.app` |
| `ANTHROPIC_API_KEY` | Claude API key | `sk-ant-...` |
| `GOOGLE_CLIENT_ID` | Google OAuth ID | `...apps.googleusercontent.com` |
| `GOOGLE_CLIENT_SECRET` | Google OAuth secret | `GOCSPX-...` |
| `FIREFLIES_CLIENT_ID` | Fireflies OAuth ID | Provided by Fireflies |
| `FIREFLIES_CLIENT_SECRET` | Fireflies OAuth secret | Provided by Fireflies |

## Post-Deployment Configuration

### 1. Setup Cron Job for Auto-Ingestion

Vercel cron is configured in `vercel.json` to run every 15 minutes.

Verify in Vercel Dashboard → Settings → Cron Jobs

### 2. Create Admin User

First user to sign up becomes workspace owner.

Or create via Prisma Studio:
```bash
npx prisma studio
```

### 3. Test OAuth Flows

1. Login to app
2. Go to Settings → Integrations
3. Click "Connect Fireflies"
4. Authorize access
5. Click "Connect Google Drive"
6. Authorize Drive access
7. Select root folder for documents
8. Verify folder structure created

### 4. Trigger First Sync

1. Go to Dashboard
2. Click "Sync Meetings"
3. Watch processing queue
4. Check Google Drive for generated documents

## Monitoring & Debugging

### View Logs
```bash
vercel logs
```

Or in Vercel Dashboard → Deployments → [deployment] → Logs

### Database Access
```bash
# Via Prisma Studio
npx prisma studio

# Via psql
psql $DATABASE_URL
```

### Check Processing Status
```sql
SELECT * FROM "ProcessingLog" ORDER BY "createdAt" DESC LIMIT 20;
```

### Verify OAuth Tokens
```sql
SELECT provider, "isActive", "lastSync" FROM "ConnectedAccount";
```

## Troubleshooting

### "Database connection error"
- Verify `DATABASE_URL` is set
- Check database is accessible from Vercel
- Run `npx prisma migrate deploy`

### "OAuth callback error"
- Verify callback URLs match in OAuth apps
- Check `NEXTAUTH_URL` is correct
- Ensure secrets are set in production

### "Meeting ingestion failing"
- Check Fireflies OAuth token is valid
- Verify MCP endpoint is accessible
- Review logs for API errors

### "Documents not appearing in Drive"
- Verify Drive OAuth token is valid
- Check folder structure was created
- Review processing logs for errors

## Scaling Considerations

### Database
- Start with Vercel Postgres (sufficient for 1-10 workspaces)
- Scale to dedicated PostgreSQL for 10+ workspaces
- Add read replicas for high read volume

### Processing
- Current: Synchronous processing in API routes
- Scale: Add Redis + BullMQ for background jobs
- Further scale: Separate processing service

### Storage
- Transcripts stored in database (acceptable for MVP)
- Scale: Move to S3/R2 for large transcripts
- Use database for metadata only

## Security Checklist

- [ ] `NEXTAUTH_SECRET` is strong random string
- [ ] OAuth tokens encrypted at rest
- [ ] HTTPS enabled (automatic on Vercel)
- [ ] Rate limiting on API routes
- [ ] Input validation on all endpoints
- [ ] Workspace isolation enforced
- [ ] Regular security updates

## Maintenance

### Update Dependencies
```bash
npm update
npx prisma migrate deploy
vercel --prod
```

### Backup Database
```bash
pg_dump $DATABASE_URL > backup.sql
```

### Monitor Performance
- Watch Vercel Analytics
- Track processing times in logs
- Monitor API response times
- Check database query performance

## Support

Issues? Check:
1. Vercel deployment logs
2. Database processing logs
3. OAuth connection status
4. API endpoint responses

Still stuck? Review codebase or contact support.
