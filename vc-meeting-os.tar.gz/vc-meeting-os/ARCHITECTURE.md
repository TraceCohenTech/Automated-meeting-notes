# VC Meeting OS - Technical Architecture

## System Overview

VC Meeting OS is a Next.js SaaS application that automates the transformation of meeting transcripts into professional deal memos and follow-up documents.

```
┌─────────────────────────────────────────────────────────────┐
│                        User Interface                        │
│  Landing Page │ Auth │ Dashboard │ Settings │ Integrations  │
└────────────┬────────────────────────────────────────────────┘
             │
┌────────────┴────────────────────────────────────────────────┐
│                     Application Layer                        │
│  Next.js App Router │ Server Actions │ API Routes           │
└────────────┬────────────────────────────────────────────────┘
             │
┌────────────┴────────────────────────────────────────────────┐
│                     Business Logic Layer                     │
│  Pipeline │ Classifier │ Generator │ Drive Service          │
└────────────┬────────────────────────────────────────────────┘
             │
┌────────────┴────────────────────────────────────────────────┐
│                      Integration Layer                       │
│  Fireflies API │ Google Drive API │ Anthropic API           │
└────────────┬────────────────────────────────────────────────┘
             │
┌────────────┴────────────────────────────────────────────────┐
│                       Data Layer                             │
│  PostgreSQL (Prisma) │ OAuth Token Storage                  │
└─────────────────────────────────────────────────────────────┘
```

## Core Components

### 1. Authentication System
**Location**: `lib/auth.ts`

- NextAuth.js with Prisma adapter
- Credentials provider for email/password
- JWT-based sessions
- Workspace association in token

**Flow**:
```
User → Login Form → NextAuth → Verify Password → Create Session → Dashboard
```

### 2. Meeting Ingestion Pipeline
**Location**: `lib/services/pipeline.ts`

**Stages**:
1. **Ingestion**: Fetch meetings from Fireflies via MCP
2. **Deduplication**: Check existing meetings by external ID
3. **Classification**: Analyze meeting type and confidence
4. **Generation**: Create AI-powered content
5. **Filing**: Save to Google Drive folders

**Processing Flow**:
```
Fireflies API
     ↓
MeetingPipeline.ingestNewMeetings()
     ↓
processMeeting() → Create DB record
     ↓
Background processing:
     ├─ classify() → Determine meeting type
     ├─ generate() → Create content
     └─ fileToGoogleDrive() → Save docs
```

### 3. Classification Engine
**Location**: `lib/services/classifier.ts`

**Signals Used**:
- Title keywords ("pitch", "demo", "fundraising")
- External participant domains
- Content analysis (mentions of "traction", "revenue", etc.)
- Historical patterns

**Scoring**:
```typescript
confidence = signals_matched / total_signals
meetingType = confidence >= 0.6 ? "startup_pitch" : 
              business_keywords ? "business_meeting" : "other"
```

### 4. Content Generator
**Location**: `lib/services/generator.ts`

**Prompts**:
- **Startup Pitch**: Comprehensive deal memo template
- **Business Meeting**: Concise follow-up brief

**Generation Process**:
```
Meeting Data → Build Prompt → Anthropic API → Parse Response → Save Artifacts
```

### 5. Google Drive Service
**Location**: `lib/services/drive.ts`

**Operations**:
- Folder creation (idempotent)
- Document creation from markdown
- Document updates (versioning)
- Permission management

**Folder Structure**:
```
VC Meeting OS/
├── 01 Startup Pitches/
├── 02 Business Meetings/
├── 03 Other/
├── 99 Inbox (Unclassified)/
└── Templates/
```

## Data Models

### Core Entities

#### Workspace
- Represents a VC firm
- Settings: autoGenerate, autoFile, confidenceThreshold
- Drive folder configuration
- Multi-tenant isolation

#### User
- Belongs to workspace
- Email-based authentication
- Role-based permissions (future)

#### ConnectedAccount
- OAuth integration storage
- Encrypted tokens
- Provider: fireflies | google_drive | google_calendar
- Refresh token handling

#### Meeting
- Synced from Fireflies
- Classification results
- Processing status tracking
- Relationships to artifacts and logs

#### Artifact
- Generated content (deal memo, follow-up)
- Versioning support
- Drive file associations
- Feedback tracking

#### ProcessingLog
- Audit trail for each stage
- Error tracking
- Performance monitoring

### Database Schema

```sql
Workspace (1) ───< (N) User
Workspace (1) ───< (N) ConnectedAccount
Workspace (1) ───< (N) Meeting
Workspace (1) ───< (N) Artifact

Meeting (1) ───< (N) Artifact
Meeting (1) ───< (N) ProcessingLog

Artifact (1) ───< (N) Feedback
```

## API Routes

### Authentication
- `POST /api/auth/signup` - Register new workspace + user
- `POST /api/auth/login` - Email/password authentication

### Meetings
- `GET /api/meetings` - List meetings with filters
- `POST /api/meetings/sync` - Trigger Fireflies sync
- `POST /api/meetings/[id]/process` - Reprocess specific meeting
- `GET /api/meetings/[id]` - Get meeting details

### Artifacts
- `GET /api/artifacts/[id]` - Retrieve artifact content
- `POST /api/artifacts/[id]/regenerate` - Create new version

### Integrations
- `POST /api/integrations/fireflies/connect` - OAuth flow
- `POST /api/integrations/drive/connect` - OAuth flow
- `GET /api/integrations/status` - Check connection status
- `POST /api/integrations/[provider]/disconnect` - Revoke access

### Cron
- `POST /api/cron/ingest` - Scheduled meeting ingestion (every 15min)

## Security Architecture

### Authentication
- Passwords hashed with bcrypt (cost factor: 12)
- JWT tokens with secure random secrets
- Session expiry: 30 days
- CSRF protection via NextAuth

### Authorization
- Workspace-level isolation in all queries
- Row-level security patterns
- API route middleware checks

### OAuth Token Storage
- Encrypted at rest in database
- Refresh token rotation
- Secure token exchange flow

### API Security
- Rate limiting (future: via Vercel Edge Config)
- Input validation with Zod schemas
- SQL injection protection via Prisma
- XSS protection via React

## Scalability Considerations

### Current Architecture (MVP)
- Synchronous processing in API routes
- Single Vercel deployment
- Adequate for: 1-50 workspaces, 100s of meetings/month

### Stage 2 (10-100 workspaces)
- Add Redis for caching
- Implement BullMQ for background jobs
- Separate cron worker instance
- Database connection pooling

### Stage 3 (100+ workspaces)
- Microservices for processing pipeline
- Separate API and processing layers
- Multi-region deployment
- Read replicas for database

## Monitoring & Observability

### Logging
- Vercel function logs
- Database processing logs
- Error tracking per meeting

### Metrics to Track
- Meeting ingestion rate
- Processing success rate
- Average processing time per stage
- API response times
- OAuth token refresh failures

### Alerts
- Processing failures
- OAuth disconnections
- Database connection errors
- API rate limit hits

## Deployment Strategy

### Infrastructure
- **Frontend/API**: Vercel (auto-scaling serverless)
- **Database**: Vercel Postgres or managed PostgreSQL
- **Background Jobs**: Vercel Cron (MVP) → BullMQ (scale)

### CI/CD
```
Git Push → GitHub → Vercel Deploy
              ↓
         Run Tests (future)
              ↓
         Database Migration
              ↓
         Production Deploy
```

### Environments
- **Development**: Local with postgres
- **Preview**: Vercel preview deployments
- **Production**: Vercel production

## Technology Choices & Rationale

### Next.js 14 (App Router)
- Server Components for performance
- Built-in API routes
- Edge runtime support
- Vercel optimization

### Prisma
- Type-safe database queries
- Migration system
- Multi-provider support
- Great developer experience

### PostgreSQL
- ACID compliance for financial data
- JSON support for flexible fields
- Proven at scale
- Managed options available

### NextAuth.js
- Battle-tested auth
- Multiple provider support
- Session management
- Security best practices

## Future Architecture Enhancements

### Phase 2
- [ ] Background job queue (BullMQ/Inngest)
- [ ] Redis caching layer
- [ ] Webhook support for Fireflies
- [ ] Real-time updates via Server-Sent Events

### Phase 3
- [ ] Multi-region deployment
- [ ] CDN for static assets
- [ ] Search with Algolia/Meilisearch
- [ ] Analytics with Mixpanel/Amplitude

### Phase 4
- [ ] AI model fine-tuning
- [ ] Custom prompt templates
- [ ] Portfolio company CRM integration
- [ ] Advanced reporting & analytics
