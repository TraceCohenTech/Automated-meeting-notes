#!/bin/bash

echo "🚀 VC Meeting OS - Quick Start Script"
echo "====================================="
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js 18+ first."
    exit 1
fi

echo "✅ Node.js $(node --version) detected"

# Check PostgreSQL
if ! command -v psql &> /dev/null; then
    echo "⚠️  PostgreSQL not detected. You'll need it for database."
    echo "   Install: https://www.postgresql.org/download/"
fi

echo ""
echo "📦 Installing dependencies..."
npm install

echo ""
echo "🔧 Setting up environment..."
if [ ! -f .env.local ]; then
    cp .env.example .env.local
    echo "✅ Created .env.local - Please edit with your values"
    echo ""
    echo "⚠️  ACTION REQUIRED:"
    echo "   1. Edit .env.local with your database and API keys"
    echo "   2. Generate NEXTAUTH_SECRET: openssl rand -base64 32"
    echo "   3. Set ANTHROPIC_API_KEY from console.anthropic.com"
    echo ""
    read -p "Press Enter after editing .env.local..."
fi

echo ""
echo "🗄️  Setting up database..."
echo "Creating database (you may be prompted for password)..."
createdb vc_meeting_os 2>/dev/null || echo "Database may already exist"

echo ""
echo "Running migrations..."
npx prisma migrate deploy

echo ""
echo "Generating Prisma client..."
npx prisma generate

echo ""
echo "✅ Setup complete!"
echo ""
echo "🎯 Next steps:"
echo "   1. Start dev server: npm run dev"
echo "   2. Open http://localhost:3000"
echo "   3. Sign up for an account"
echo "   4. Connect Fireflies and Google Drive"
echo ""
echo "📚 Documentation:"
echo "   - SETUP.md       - Detailed setup guide"
echo "   - README.md      - Project overview"
echo "   - DEPLOYMENT.md  - Production deployment"
echo ""
echo "Happy building! 🎉"
