# VC Meeting OS

Production SaaS application that automatically transforms Fireflies meeting transcripts into professional deal memos and organized Google Drive documents.

## Stack

- Next.js 14 (App Router)
- TypeScript
- Prisma + PostgreSQL
- Tailwind CSS + Radix UI
- NextAuth.js
- Claude AI
- Google Drive API
- Fireflies API (via MCP)

## Quick Deploy

```bash
# Install dependencies
npm install

# Set up database
npx prisma generate
npx prisma db push

# Deploy to Vercel
vercel --prod
```

## Environment Variables

See `.env.example` for required variables.

## Features

✅ Email authentication with NextAuth
✅ OAuth integration (Fireflies + Google Drive)
✅ Automatic meeting ingestion
✅ AI-powered classification
✅ Claude-generated deal memos & briefs
✅ Google Drive auto-filing
✅ Background processing via Vercel Cron
✅ Complete audit trail

## Architecture

Landing → Auth → Dashboard → Background Pipeline

Pipeline: Fireflies → Classify → AI Generate → Google Drive

## Success Criteria Met

✅ User sign up
✅ Connect Fireflies + Google Drive
✅ Auto-ingest meetings
✅ Generate memos in Drive
✅ View in dashboard

Built for venture capitalists. Zero manual work after setup.
