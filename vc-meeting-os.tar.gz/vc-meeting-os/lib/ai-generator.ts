/**
 * AI Document Generation Engine
 * Creates structured outputs using Claude AI
 */

import { MeetingType } from "@prisma/client";

const PROMPT_VERSIONS = {
  DEAL_MEMO_V1: '2026-01-13-v1',
  BUSINESS_BRIEF_V1: '2026-01-13-v1',
  ACTION_ITEMS_V1: '2026-01-13-v1',
};

export interface GenerationResult {
  dealMemo?: string;
  meetingBrief?: string;
  actionItems?: string;
  followUpEmail?: string;
  internalSummary?: string;
  promptVersion: string;
}

export class AIGenerator {
  private apiKey: string;

  constructor() {
    this.apiKey = process.env.ANTHROPIC_API_KEY!;
  }

  /**
   * Generate all outputs for a meeting
   */
  async generateOutputs(
    meeting: {
      title: string;
      date: Date;
      duration: number;
      attendees: string[];
      transcript: string;
      summary?: string;
    },
    type: MeetingType
  ): Promise<GenerationResult> {
    if (type === MeetingType.STARTUP_PITCH) {
      return this.generateStartupPitchOutputs(meeting);
    } else if (type === MeetingType.BUSINESS_MEETING) {
      return this.generateBusinessMeetingOutputs(meeting);
    } else {
      return this.generateBasicOutputs(meeting);
    }
  }

  /**
   * Generate outputs for startup pitch
   */
  private async generateStartupPitchOutputs(meeting: any): Promise<GenerationResult> {
    const prompt = this.buildDealMemoPrompt(meeting);
    
    const response = await this.callClaude(prompt);
    
    return {
      dealMemo: response,
      actionItems: await this.extractActionItems(meeting.transcript),
      internalSummary: this.extractExecutiveSummary(response),
      promptVersion: PROMPT_VERSIONS.DEAL_MEMO_V1,
    };
  }

  /**
   * Generate outputs for business meeting
   */
  private async generateBusinessMeetingOutputs(meeting: any): Promise<GenerationResult> {
    const prompt = this.buildBusinessBriefPrompt(meeting);
    
    const response = await this.callClaude(prompt);
    
    return {
      meetingBrief: response,
      actionItems: await this.extractActionItems(meeting.transcript),
      followUpEmail: await this.generateFollowUpEmail(meeting),
      promptVersion: PROMPT_VERSIONS.BUSINESS_BRIEF_V1,
    };
  }

  /**
   * Generate basic outputs
   */
  private async generateBasicOutputs(meeting: any): Promise<GenerationResult> {
    return {
      internalSummary: meeting.summary || 'No summary available',
      actionItems: await this.extractActionItems(meeting.transcript),
      promptVersion: PROMPT_VERSIONS.ACTION_ITEMS_V1,
    };
  }

  /**
   * Build Deal Memo prompt for startup pitches
   */
  private buildDealMemoPrompt(meeting: any): string {
    return `You are a venture capital analyst creating a professional deal memo. Analyze this startup pitch meeting and create a comprehensive, partner-ready deal memo.

MEETING DETAILS:
Title: ${meeting.title}
Date: ${meeting.date.toLocaleDateString()}
Duration: ${meeting.duration} minutes
Attendees: ${meeting.attendees.join(', ')}

TRANSCRIPT:
${meeting.transcript}

${meeting.summary ? `SUMMARY:\n${meeting.summary}\n\n` : ''}

Create a deal memo with the following structure. Be analytical, neutral, and skimmable:

# DEAL MEMO

## Company Overview
Brief description of what the company does (2-3 sentences)

## Executive Summary
High-level investment opportunity summary (3-4 sentences)

## Team & Founders
- Backgrounds and relevant experience
- Why they're suited for this problem
- Team composition and gaps

## Product & Technology
- What they've built
- Technical approach and defensibility
- Product-market fit signals

## Market Opportunity
- Target market size and characteristics
- Growth potential
- Market timing

## Business Model
- Revenue model
- Unit economics (if discussed)
- Go-to-market strategy

## Traction & Metrics
- Current metrics (users, revenue, growth)
- Key milestones achieved
- Customer validation

## Competition & Differentiation
- Competitive landscape
- Unique advantages
- Moats and defensibility

## Investment Terms
- Amount raising
- Valuation (if discussed)
- Key terms
- Use of funds

## Risks & Concerns
- Key risks identified
- Mitigation strategies
- Red flags or open questions

## Next Steps
Specific actions required for further due diligence

---

Format as clean markdown. Use bullet points where appropriate. Be concise but comprehensive. Maintain neutral, analytical tone throughout.`;
  }

  /**
   * Build Business Brief prompt
   */
  private buildBusinessBriefPrompt(meeting: any): string {
    return `Create a professional meeting brief from this business meeting.

MEETING DETAILS:
Title: ${meeting.title}
Date: ${meeting.date.toLocaleDateString()}
Duration: ${meeting.duration} minutes
Attendees: ${meeting.attendees.join(', ')}

TRANSCRIPT:
${meeting.transcript}

Create a brief with this structure:

# MEETING BRIEF

## Meeting Summary
2-3 sentence overview of the meeting

## Key Discussion Points
- Main topics covered (bullet points)

## Decisions Made
- Key decisions and their rationale

## Action Items
- Task | Owner | Deadline
(Extract from transcript)

## Strategic Takeaways
- Important insights or implications

## Next Steps
- What happens next

Keep it concise and actionable. Use bullet points. Focus on decisions and actions.`;
  }

  /**
   * Extract action items from transcript
   */
  private async extractActionItems(transcript: string): Promise<string> {
    const prompt = `Extract all action items from this meeting transcript. Format as a clear list.

TRANSCRIPT:
${transcript}

Return ONLY the action items in this format:
- [Action] - [Owner if mentioned] - [Deadline if mentioned]

Be specific and actionable. If no clear action items, return "No specific action items identified."`;

    return this.callClaude(prompt);
  }

  /**
   * Generate follow-up email
   */
  private async generateFollowUpEmail(meeting: any): Promise<string> {
    const prompt = `Draft a professional follow-up email for this meeting.

MEETING: ${meeting.title}
DATE: ${meeting.date.toLocaleDateString()}
ATTENDEES: ${meeting.attendees.join(', ')}

SUMMARY: ${meeting.summary || 'See transcript'}

Create a concise follow-up email that:
- Thanks participants
- Summarizes key points
- Lists action items
- Notes next steps

Keep it under 200 words. Professional but friendly tone.`;

    return this.callClaude(prompt);
  }

  /**
   * Extract executive summary from deal memo
   */
  private extractExecutiveSummary(dealMemo: string): string {
    const summaryMatch = dealMemo.match(/## Executive Summary\n([\s\S]+?)(?=\n##|\n$)/);
    return summaryMatch ? summaryMatch[1].trim() : dealMemo.substring(0, 500);
  }

  /**
   * Call Claude API
   */
  private async callClaude(prompt: string): Promise<string> {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": this.apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 4000,
        messages: [{
          role: "user",
          content: prompt
        }]
      })
    });

    if (!response.ok) {
      throw new Error(`Claude API error: ${response.statusText}`);
    }

    const data = await response.json();
    const textContent = data.content
      .filter((item: any) => item.type === "text")
      .map((item: any) => item.text)
      .join("\n");

    return textContent;
  }
}

/**
 * Format document for Google Docs
 */
export function formatForGoogleDocs(content: string, title: string, date: Date): string {
  return `${title}
${date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}

${'='.repeat(80)}

${content}

${'='.repeat(80)}

Generated by VC Meeting OS
`;
}
