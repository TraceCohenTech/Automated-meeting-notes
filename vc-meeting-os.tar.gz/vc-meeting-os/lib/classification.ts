/**
 * Meeting Classification Engine
 * Determines meeting type based on multiple signals
 */

import { MeetingType } from "@prisma/client";

export interface ClassificationResult {
  type: MeetingType;
  confidence: number;
  inferredCompany?: string;
  reasoning: string[];
}

export class ClassificationEngine {
  /**
   * Classify a meeting based on multiple signals
   */
  static async classify(meeting: {
    title: string;
    transcript: string;
    attendees: string[];
    summary?: string;
  }): Promise<ClassificationResult> {
    const signals: string[] = [];
    let score = 0;
    let maxScore = 0;
    let type: MeetingType = MeetingType.UNCLASSIFIED;
    let inferredCompany: string | undefined;

    // Signal 1: Title analysis (weight: 3)
    maxScore += 3;
    const titleResult = this.analyzeTitleForType(meeting.title);
    if (titleResult.type !== MeetingType.UNCLASSIFIED) {
      score += 3 * titleResult.confidence;
      type = titleResult.type;
      signals.push(`Title indicates ${titleResult.type} (${titleResult.confidence.toFixed(2)})`);
    }

    // Signal 2: Keyword analysis in transcript (weight: 4)
    maxScore += 4;
    const transcriptResult = this.analyzeTranscriptKeywords(
      meeting.transcript || meeting.summary || ''
    );
    if (transcriptResult.type !== MeetingType.UNCLASSIFIED) {
      score += 4 * transcriptResult.confidence;
      if (score / maxScore > 0.5) {
        type = transcriptResult.type;
      }
      signals.push(`Transcript analysis: ${transcriptResult.type} (${transcriptResult.confidence.toFixed(2)})`);
      inferredCompany = transcriptResult.company;
    }

    // Signal 3: Attendee domain analysis (weight: 2)
    maxScore += 2;
    const attendeeResult = this.analyzeAttendeeDomains(meeting.attendees);
    if (attendeeResult.hasExternal) {
      score += 2 * attendeeResult.confidence;
      signals.push(`External attendees detected (${attendeeResult.confidence.toFixed(2)})`);
    }

    // Signal 4: Company name extraction (weight: 1)
    maxScore += 1;
    if (!inferredCompany) {
      const companyName = this.extractCompanyName(meeting.title, meeting.transcript || '');
      if (companyName) {
        inferredCompany = companyName;
        score += 1;
        signals.push(`Company identified: ${companyName}`);
      }
    }

    const confidence = maxScore > 0 ? score / maxScore : 0;

    // Confidence threshold for classification
    if (confidence < 0.6) {
      type = MeetingType.UNCLASSIFIED;
      signals.push(`Confidence too low (${confidence.toFixed(2)} < 0.6) - marked as unclassified`);
    }

    return {
      type,
      confidence,
      inferredCompany,
      reasoning: signals,
    };
  }

  /**
   * Analyze meeting title for type indicators
   */
  private static analyzeTitleForType(title: string): {
    type: MeetingType;
    confidence: number;
  } {
    const titleLower = title.toLowerCase();

    // Startup pitch indicators
    const pitchKeywords = [
      'pitch',
      'demo',
      'startup',
      'founder',
      'funding',
      'seed',
      'series a',
      'series b',
      'pre-seed',
      'hubble call'
    ];
    
    const pitchMatches = pitchKeywords.filter(kw => titleLower.includes(kw)).length;
    if (pitchMatches >= 1) {
      return {
        type: MeetingType.STARTUP_PITCH,
        confidence: Math.min(pitchMatches * 0.4, 1.0),
      };
    }

    // Business meeting indicators
    const businessKeywords = [
      'weekly',
      'standup',
      'sync',
      'review',
      'planning',
      'strategy',
      'portfolio',
      'lp',
      'limited partner',
      'investment committee',
      'ic meeting'
    ];
    
    const businessMatches = businessKeywords.filter(kw => titleLower.includes(kw)).length;
    if (businessMatches >= 1) {
      return {
        type: MeetingType.BUSINESS_MEETING,
        confidence: Math.min(businessMatches * 0.4, 1.0),
      };
    }

    return {
      type: MeetingType.UNCLASSIFIED,
      confidence: 0,
    };
  }

  /**
   * Analyze transcript for keyword signals
   */
  private static analyzeTranscriptKeywords(text: string): {
    type: MeetingType;
    confidence: number;
    company?: string;
  } {
    const textLower = text.toLowerCase();
    const words = textLower.split(/\s+/);

    // Startup pitch indicators
    const pitchIndicators = [
      'raising',
      'valuation',
      'revenue',
      'traction',
      'product-market fit',
      'cap table',
      'term sheet',
      'convertible note',
      'safe',
      'customers',
      'mrr',
      'arr',
      'growth rate',
      'unit economics',
      'burn rate',
      'runway'
    ];

    const pitchScore = pitchIndicators.filter(indicator => 
      textLower.includes(indicator)
    ).length;

    if (pitchScore >= 3) {
      return {
        type: MeetingType.STARTUP_PITCH,
        confidence: Math.min(pitchScore / 8, 1.0),
      };
    }

    // Business meeting indicators
    const businessIndicators = [
      'action items',
      'follow up',
      'next steps',
      'agenda',
      'quarterly',
      'portfolio company',
      'board meeting',
      'update',
      'review'
    ];

    const businessScore = businessIndicators.filter(indicator =>
      textLower.includes(indicator)
    ).length;

    if (businessScore >= 2) {
      return {
        type: MeetingType.BUSINESS_MEETING,
        confidence: Math.min(businessScore / 5, 1.0),
      };
    }

    return {
      type: MeetingType.UNCLASSIFIED,
      confidence: 0,
    };
  }

  /**
   * Analyze attendee email domains
   */
  private static analyzeAttendeeDomains(attendees: string[]): {
    hasExternal: boolean;
    confidence: number;
  } {
    if (attendees.length === 0) {
      return { hasExternal: false, confidence: 0 };
    }

    // Extract domains
    const domains = attendees
      .map(email => email.split('@')[1]?.toLowerCase())
      .filter(Boolean);

    if (domains.length === 0) {
      return { hasExternal: false, confidence: 0 };
    }

    // Check for domain diversity (indicator of external meeting)
    const uniqueDomains = new Set(domains);
    const domainDiversity = uniqueDomains.size / domains.length;

    // More than 50% unique domains suggests external participants
    const hasExternal = domainDiversity > 0.5;
    
    return {
      hasExternal,
      confidence: domainDiversity,
    };
  }

  /**
   * Extract potential company name
   */
  private static extractCompanyName(title: string, transcript: string): string | undefined {
    // Try to extract from title first
    // Common patterns: "Company Name - Meeting", "Meeting with Company Name"
    const titleMatch = title.match(/^([A-Z][A-Za-z0-9\s&.]+?)(?:\s*[-:]|\s+(?:Call|Meeting|Demo|Pitch))/);
    if (titleMatch) {
      return titleMatch[1].trim();
    }

    // Try to extract from early in transcript
    const firstLines = transcript.split('\n').slice(0, 5).join(' ');
    const companyPattern = /(?:at|from|with|company called)\s+([A-Z][A-Za-z0-9\s&.]{2,30}?)(?:\s+(?:is|has|was|does|provides|offers))/;
    const match = firstLines.match(companyPattern);
    
    if (match) {
      return match[1].trim();
    }

    return undefined;
  }
}
