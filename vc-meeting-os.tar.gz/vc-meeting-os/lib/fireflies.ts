/**
 * Fireflies.ai API Client
 * Handles authentication and meeting data retrieval
 */

export interface FirefliesMeeting {
  id: string;
  title: string;
  date: string;
  duration: number;
  organizer?: string;
  attendees: string[];
  transcript: string;
  summary?: string;
}

export class FirefliesClient {
  private accessToken: string;

  constructor(accessToken: string) {
    this.accessToken = accessToken;
  }

  /**
   * Fetch recent meetings
   */
  async getMeetings(limit: number = 50): Promise<FirefliesMeeting[]> {
    // In production, this would use the actual Fireflies API via MCP
    // For now, we'll use the MCP server through Claude's API
    
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY!,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 4000,
        mcp_servers: [{
          type: "url",
          url: "https://api.fireflies.ai/mcp",
          name: "fireflies-mcp"
        }],
        messages: [{
          role: "user",
          content: `Use fireflies_get_transcripts to get the last ${limit} meetings. Return as JSON array with: id, title, date, duration, organizer, attendees, transcript, summary.`
        }]
      })
    });

    if (!response.ok) {
      throw new Error(`Fireflies API error: ${response.statusText}`);
    }

    const data = await response.json();
    return this.parseMeetingsFromResponse(data);
  }

  /**
   * Get single meeting details
   */
  async getMeeting(meetingId: string): Promise<FirefliesMeeting> {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY!,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 4000,
        mcp_servers: [{
          type: "url",
          url: "https://api.fireflies.ai/mcp",
          name: "fireflies-mcp"
        }],
        messages: [{
          role: "user",
          content: `Use fireflies_fetch to get meeting ID ${meetingId}. Return as JSON with: id, title, date, duration, organizer, attendees, transcript, summary.`
        }]
      })
    });

    if (!response.ok) {
      throw new Error(`Fireflies API error: ${response.statusText}`);
    }

    const data = await response.json();
    const meetings = this.parseMeetingsFromResponse(data);
    return meetings[0];
  }

  /**
   * Parse meetings from Claude API response
   */
  private parseMeetingsFromResponse(data: any): FirefliesMeeting[] {
    const meetings: FirefliesMeeting[] = [];
    
    try {
      // Extract tool results
      const toolResults = data.content
        .filter((item: any) => item.type === "mcp_tool_result")
        .map((item: any) => item.content?.[0]?.text || "")
        .join("\n");

      // Parse meeting data
      const meetingBlocks = toolResults.split(/(?=- id:)/);
      
      for (const block of meetingBlocks) {
        if (!block.trim()) continue;
        
        const meeting: FirefliesMeeting = {
          id: this.extractField(block, 'id'),
          title: this.extractField(block, 'title'),
          date: this.extractField(block, 'dateString'),
          duration: parseInt(this.extractField(block, 'duration')) || 0,
          organizer: this.extractField(block, 'organizer_email'),
          attendees: [],
          transcript: this.extractField(block, 'transcript') || '',
          summary: this.extractField(block, 'short_summary'),
        };

        // Extract participants
        const participantsMatch = block.match(/participants\[(\d+)\]:\s*(.+)/);
        if (participantsMatch) {
          meeting.attendees = participantsMatch[2].split(',').map(p => p.trim());
        }

        if (meeting.id) {
          meetings.push(meeting);
        }
      }
    } catch (error) {
      console.error("Error parsing Fireflies meetings:", error);
    }

    return meetings;
  }

  private extractField(text: string, fieldName: string): string {
    const regex = new RegExp(`${fieldName}:\\s*"?([^"\\n]+)"?`, 'i');
    const match = text.match(regex);
    return match ? match[1].trim() : '';
  }

  /**
   * Validate OAuth token
   */
  static async validateToken(accessToken: string): Promise<boolean> {
    try {
      const client = new FirefliesClient(accessToken);
      await client.getMeetings(1);
      return true;
    } catch (error) {
      return false;
    }
  }
}
