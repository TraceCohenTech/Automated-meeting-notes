/**
 * Google Drive Client
 * Handles folder creation, document management, and OAuth
 */

import { google } from 'googleapis';

export interface DriveFolder {
  id: string;
  name: string;
  webViewLink?: string;
}

export class GoogleDriveClient {
  private drive: any;
  private docs: any;

  constructor(accessToken: string, refreshToken?: string) {
    const oauth2Client = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET,
      process.env.GOOGLE_REDIRECT_URI
    );

    oauth2Client.setCredentials({
      access_token: accessToken,
      refresh_token: refreshToken,
    });

    this.drive = google.drive({ version: 'v3', auth: oauth2Client });
    this.docs = google.docs({ version: 'v1', auth: oauth2Client });
  }

  /**
   * Initialize folder structure
   */
  async initializeFolderStructure(rootFolderId?: string): Promise<{
    root: DriveFolder;
    folders: { [key: string]: DriveFolder };
  }> {
    // Create root folder if not provided
    let rootFolder: DriveFolder;
    
    if (rootFolderId) {
      const folder = await this.drive.files.get({
        fileId: rootFolderId,
        fields: 'id, name, webViewLink',
      });
      rootFolder = {
        id: folder.data.id,
        name: folder.data.name,
        webViewLink: folder.data.webViewLink,
      };
    } else {
      rootFolder = await this.createFolder('VC Meeting OS', undefined);
    }

    // Create subfolder structure
    const subfolders = {
      startupPitches: await this.createFolder('01 Startup Pitches', rootFolder.id),
      businessMeetings: await this.createFolder('02 Business Meetings', rootFolder.id),
      other: await this.createFolder('03 Other', rootFolder.id),
      inbox: await this.createFolder('99 Inbox (Unclassified)', rootFolder.id),
      templates: await this.createFolder('Templates', rootFolder.id),
    };

    return {
      root: rootFolder,
      folders: subfolders,
    };
  }

  /**
   * Create a folder (idempotent)
   */
  async createFolder(name: string, parentId?: string): Promise<DriveFolder> {
    // Check if folder already exists
    const query = parentId
      ? `name='${name}' and '${parentId}' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false`
      : `name='${name}' and mimeType='application/vnd.google-apps.folder' and trashed=false`;

    const existingFolders = await this.drive.files.list({
      q: query,
      fields: 'files(id, name, webViewLink)',
      spaces: 'drive',
    });

    if (existingFolders.data.files && existingFolders.data.files.length > 0) {
      const folder = existingFolders.data.files[0];
      return {
        id: folder.id,
        name: folder.name,
        webViewLink: folder.webViewLink,
      };
    }

    // Create new folder
    const fileMetadata: any = {
      name,
      mimeType: 'application/vnd.google-apps.folder',
    };

    if (parentId) {
      fileMetadata.parents = [parentId];
    }

    const folder = await this.drive.files.create({
      requestBody: fileMetadata,
      fields: 'id, name, webViewLink',
    });

    return {
      id: folder.data.id,
      name: folder.data.name,
      webViewLink: folder.data.webViewLink,
    };
  }

  /**
   * Create a Google Doc with content
   */
  async createDocument(
    title: string,
    content: string,
    folderId: string
  ): Promise<{ id: string; url: string }> {
    // Create blank document
    const doc = await this.drive.files.create({
      requestBody: {
        name: title,
        mimeType: 'application/vnd.google-apps.document',
        parents: [folderId],
      },
      fields: 'id, webViewLink',
    });

    const documentId = doc.data.id;

    // Insert content
    await this.docs.documents.batchUpdate({
      documentId,
      requestBody: {
        requests: [
          {
            insertText: {
              location: { index: 1 },
              text: content,
            },
          },
        ],
      },
    });

    return {
      id: documentId,
      url: doc.data.webViewLink,
    };
  }

  /**
   * Update existing document
   */
  async updateDocument(documentId: string, content: string): Promise<void> {
    // Get current content length
    const doc = await this.docs.documents.get({ documentId });
    const endIndex = doc.data.body.content[doc.data.body.content.length - 1].endIndex - 1;

    // Delete old content and insert new
    await this.docs.documents.batchUpdate({
      documentId,
      requestBody: {
        requests: [
          {
            deleteContentRange: {
              range: {
                startIndex: 1,
                endIndex,
              },
            },
          },
          {
            insertText: {
              location: { index: 1 },
              text: content,
            },
          },
        ],
      },
    });
  }

  /**
   * Move file to folder
   */
  async moveFile(fileId: string, targetFolderId: string): Promise<void> {
    // Get current parents
    const file = await this.drive.files.get({
      fileId,
      fields: 'parents',
    });

    const previousParents = file.data.parents?.join(',') || '';

    // Move file
    await this.drive.files.update({
      fileId,
      addParents: targetFolderId,
      removeParents: previousParents,
      fields: 'id, parents',
    });
  }

  /**
   * List files in folder
   */
  async listFiles(folderId: string): Promise<any[]> {
    const response = await this.drive.files.list({
      q: `'${folderId}' in parents and trashed=false`,
      fields: 'files(id, name, mimeType, createdTime, modifiedTime, webViewLink)',
      orderBy: 'modifiedTime desc',
    });

    return response.data.files || [];
  }

  /**
   * Validate OAuth token
   */
  static async validateToken(accessToken: string): Promise<boolean> {
    try {
      const oauth2Client = new google.auth.OAuth2(
        process.env.GOOGLE_CLIENT_ID,
        process.env.GOOGLE_CLIENT_SECRET
      );

      oauth2Client.setCredentials({ access_token: accessToken });

      const drive = google.drive({ version: 'v3', auth: oauth2Client });
      await drive.files.list({ pageSize: 1 });
      
      return true;
    } catch (error) {
      return false;
    }
  }
}
