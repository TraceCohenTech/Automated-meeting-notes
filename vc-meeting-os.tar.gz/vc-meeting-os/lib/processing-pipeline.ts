/**
 * Meeting Processing Pipeline
 * Handles end-to-end processing: ingest → classify → generate → file
 */

import { prisma } from "./prisma";
import { FirefliesClient } from "./fireflies";
import { GoogleDriveClient } from "./google-drive";
import { ClassificationEngine } from "./classification";
import { AIGenerator, formatForGoogleDocs } from "./ai-generator";
import { MeetingType, ProcessingStatus, ArtifactType } from "@prisma/client";

export class ProcessingPipeline {
  private workspaceId: string;

  constructor(workspaceId: string) {
    this.workspaceId = workspaceId;
  }

  /**
   * Process a single meeting end-to-end
   */
  async processMeeting(meetingId: string): Promise<void> {
    const meeting = await prisma.meeting.findUnique({
      where: { id: meetingId },
    });

    if (!meeting || meeting.isProcessed) {
      return;
    }

    try {
      await this.logProcessing(meetingId, 'ingestion', ProcessingStatus.IN_PROGRESS);

      // Step 1: Classify
      await this.logProcessing(meetingId, 'classification', ProcessingStatus.IN_PROGRESS);
      const classification = await ClassificationEngine.classify({
        title: meeting.title,
        transcript: meeting.transcript,
        attendees: meeting.attendees,
        summary: meeting.summary || undefined,
      });

      await prisma.meeting.update({
        where: { id: meetingId },
        data: {
          meetingType: classification.type,
          confidence: classification.confidence,
          inferredCompany: classification.inferredCompany,
          classifiedAt: new Date(),
        },
      });

      await this.logProcessing(meetingId, 'classification', ProcessingStatus.COMPLETED, 
        `Classified as ${classification.type} (confidence: ${classification.confidence.toFixed(2)})`);

      // Step 2: Generate documents
      const settings = await prisma.workspaceSettings.findUnique({
        where: { workspaceId: this.workspaceId },
      });

      if (!settings?.autoGenerate) {
        await prisma.meeting.update({
          where: { id: meetingId },
          data: { isProcessed: true, processedAt: new Date() },
        });
        return;
      }

      await this.logProcessing(meetingId, 'generation', ProcessingStatus.IN_PROGRESS);
      
      const generator = new AIGenerator();
      const outputs = await generator.generateOutputs(meeting, classification.type);

      // Save artifacts
      if (outputs.dealMemo) {
        await prisma.artifact.create({
          data: {
            meetingId,
            type: ArtifactType.DEAL_MEMO,
            content: outputs.dealMemo,
            promptVersion: outputs.promptVersion,
          },
        });
      }

      if (outputs.meetingBrief) {
        await prisma.artifact.create({
          data: {
            meetingId,
            type: ArtifactType.MEETING_BRIEF,
            content: outputs.meetingBrief,
            promptVersion: outputs.promptVersion,
          },
        });
      }

      if (outputs.actionItems) {
        await prisma.artifact.create({
          data: {
            meetingId,
            type: ArtifactType.ACTION_ITEMS,
            content: outputs.actionItems,
            promptVersion: outputs.promptVersion,
          },
        });
      }

      await this.logProcessing(meetingId, 'generation', ProcessingStatus.COMPLETED);

      // Step 3: File to Google Drive
      if (settings?.autoFile && settings.googleDriveRootFolderId) {
        await this.logProcessing(meetingId, 'filing', ProcessingStatus.IN_PROGRESS);
        await this.fileToGoogleDrive(meetingId, classification.type, outputs);
        await this.logProcessing(meetingId, 'filing', ProcessingStatus.COMPLETED);
      }

      // Mark as processed
      await prisma.meeting.update({
        where: { id: meetingId },
        data: {
          isProcessed: true,
          processingStartedAt: new Date(),
          processedAt: new Date(),
        },
      });

    } catch (error: any) {
      await this.logProcessing(
        meetingId,
        'processing',
        ProcessingStatus.FAILED,
        error.message
      );
      throw error;
    }
  }

  /**
   * File documents to Google Drive
   */
  private async fileToGoogleDrive(
    meetingId: string,
    type: MeetingType,
    outputs: any
  ): Promise<void> {
    const account = await prisma.connectedAccount.findFirst({
      where: {
        workspaceId: this.workspaceId,
        provider: 'google_drive',
        isActive: true,
      },
    });

    if (!account) {
      throw new Error('Google Drive not connected');
    }

    const driveClient = new GoogleDriveClient(
      account.accessToken,
      account.refreshToken || undefined
    );

    const meeting = await prisma.meeting.findUnique({
      where: { id: meetingId },
    });

    if (!meeting) return;

    // Determine target folder
    const settings = await prisma.workspaceSettings.findUnique({
      where: { workspaceId: this.workspaceId },
    });

    if (!settings?.googleDriveRootFolderId) return;

    // Get appropriate folder
    let folderId: string;
    const folderMap: Record<string, string> = {
      [MeetingType.STARTUP_PITCH]: '01 Startup Pitches',
      [MeetingType.BUSINESS_MEETING]: '02 Business Meetings',
      [MeetingType.OTHER]: '03 Other',
      [MeetingType.UNCLASSIFIED]: '99 Inbox (Unclassified)',
    };

    const targetFolderName = folderMap[type];
    folderId = await this.findOrCreateFolder(driveClient, targetFolderName, settings.googleDriveRootFolderId);

    // Create document
    const primaryContent = outputs.dealMemo || outputs.meetingBrief || outputs.internalSummary || 'No content';
    const formattedContent = formatForGoogleDocs(primaryContent, meeting.title, meeting.date);

    const doc = await driveClient.createDocument(
      `${meeting.date.toISOString().split('T')[0]} - ${meeting.title}`,
      formattedContent,
      folderId
    );

    // Update artifact with Drive info
    const artifact = await prisma.artifact.findFirst({
      where: { meetingId, type: outputs.dealMemo ? ArtifactType.DEAL_MEMO : ArtifactType.MEETING_BRIEF },
    });

    if (artifact) {
      await prisma.artifact.update({
        where: { id: artifact.id },
        data: {
          driveFileId: doc.id,
          driveFileUrl: doc.url,
          driveFolderId: folderId,
        },
      });
    }
  }

  /**
   * Find or create folder
   */
  private async findOrCreateFolder(
    client: GoogleDriveClient,
    name: string,
    parentId: string
  ): Promise<string> {
    const folder = await client.createFolder(name, parentId);
    return folder.id;
  }

  /**
   * Log processing step
   */
  private async logProcessing(
    meetingId: string,
    step: string,
    status: ProcessingStatus,
    message?: string
  ): Promise<void> {
    await prisma.processingLog.create({
      data: {
        meetingId,
        step,
        status,
        message,
      },
    });
  }

  /**
   * Ingest meetings from Fireflies
   */
  async ingestMeetings(): Promise<number> {
    const account = await prisma.connectedAccount.findFirst({
      where: {
        workspaceId: this.workspaceId,
        provider: 'fireflies',
        isActive: true,
      },
    });

    if (!account) {
      throw new Error('Fireflies not connected');
    }

    const client = new FirefliesClient(account.accessToken);
    const meetings = await client.getMeetings(50);

    let ingested = 0;

    for (const meeting of meetings) {
      // Check if already exists
      const existing = await prisma.meeting.findUnique({
        where: { firefliesId: meeting.id },
      });

      if (existing) continue;

      // Create new meeting
      await prisma.meeting.create({
        data: {
          workspaceId: this.workspaceId,
          firefliesId: meeting.id,
          title: meeting.title,
          date: new Date(meeting.date),
          duration: meeting.duration,
          organizer: meeting.organizer,
          attendees: meeting.attendees,
          transcript: meeting.transcript,
          summary: meeting.summary,
        },
      });

      ingested++;
    }

    // Update last sync
    await prisma.connectedAccount.update({
      where: { id: account.id },
      data: { lastSyncAt: new Date() },
    });

    return ingested;
  }
}
