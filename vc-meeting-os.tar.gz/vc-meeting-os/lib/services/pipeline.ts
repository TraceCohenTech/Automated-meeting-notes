/**
 * Meeting Processing Pipeline
 * Orchestrates ingestion, classification, generation, and filing
 */

import { prisma } from '@/lib/prisma'
import { FirefliesService } from './fireflies'
import { MeetingClassifier } from './classifier'
import { ContentGenerator } from './generator'
import { GoogleDriveService } from './drive'

export class MeetingPipeline {
  private workspaceId: string

  constructor(workspaceId: string) {
    this.workspaceId = workspaceId
  }

  /**
   * Ingest and process new meetings
   */
  async ingestNewMeetings(): Promise<{ processed: number; failed: number }> {
    let processed = 0
    let failed = 0

    try {
      // Get Fireflies access token
      const firefliesAccount = await prisma.connectedAccount.findFirst({
        where: { workspaceId: this.workspaceId, provider: 'fireflies' }
      })

      if (!firefliesAccount?.accessToken) {
        throw new Error('Fireflies not connected')
      }

      // Fetch recent meetings
      const fireflies = new FirefliesService(firefliesAccount.accessToken)
      const meetings = await fireflies.fetchRecentMeetings(20)

      // Process each meeting
      for (const meeting of meetings) {
        try {
          await this.processMeeting(meeting)
          processed++
        } catch (error) {
          console.error(`Failed to process meeting ${meeting.id}:`, error)
          failed++
        }
      }

      // Update last sync
      await prisma.connectedAccount.update({
        where: { id: firefliesAccount.id },
        data: { lastSync: new Date() }
      })
    } catch (error) {
      console.error('Error in ingestion pipeline:', error)
    }

    return { processed, failed }
  }

  /**
   * Process a single meeting through the full pipeline
   */
  async processMeeting(externalMeeting: any): Promise<string> {
    // Check if already exists
    const existing = await prisma.meeting.findFirst({
      where: { workspaceId: this.workspaceId, externalId: externalMeeting.id }
    })

    if (existing) {
      return existing.id
    }

    // Create meeting record
    const meeting = await prisma.meeting.create({
      data: {
        workspaceId: this.workspaceId,
        externalId: externalMeeting.id,
        title: externalMeeting.title,
        date: new Date(externalMeeting.date),
        duration: externalMeeting.duration || 0,
        organizer: externalMeeting.organizer,
        participants: externalMeeting.participants || [],
        transcript: externalMeeting.transcript,
        summary: externalMeeting.summary,
        keywords: externalMeeting.keywords || [],
        status: 'pending',
      }
    })

    // Log start
    await this.log(meeting.id, 'ingestion', 'completed', 'Meeting ingested')

    // Process in background (in production, use queue)
    this.processInBackground(meeting.id).catch(console.error)

    return meeting.id
  }

  /**
   * Background processing (classification + generation + filing)
   */
  private async processInBackground(meetingId: string): Promise<void> {
    try {
      await prisma.meeting.update({
        where: { id: meetingId },
        data: { status: 'processing' }
      })

      const meeting = await prisma.meeting.findUnique({
        where: { id: meetingId }
      })

      if (!meeting) return

      // Step 1: Classify
      await this.log(meetingId, 'classification', 'started')
      const classifier = new MeetingClassifier()
      const classification = classifier.classify({
        title: meeting.title,
        participants: meeting.participants,
        summary: meeting.summary || undefined,
        transcript: meeting.transcript || undefined,
      })

      await prisma.meeting.update({
        where: { id: meetingId },
        data: {
          meetingType: classification.meetingType,
          confidence: classification.confidence,
          companyName: classification.companyName,
        }
      })
      await this.log(meetingId, 'classification', 'completed', 
        `Classified as ${classification.meetingType} (${Math.round(classification.confidence * 100)}%)`)

      // Step 2: Generate content
      const workspace = await prisma.workspace.findUnique({
        where: { id: this.workspaceId }
      })

      if (!workspace?.autoGenerate) {
        await this.log(meetingId, 'generation', 'skipped', 'Auto-generate disabled')
        await prisma.meeting.update({
          where: { id: meetingId },
          data: { status: 'completed', processedAt: new Date() }
        })
        return
      }

      await this.log(meetingId, 'generation', 'started')
      const generator = new ContentGenerator()
      const content = await generator.generate({
        title: meeting.title,
        date: meeting.date,
        duration: meeting.duration,
        participants: meeting.participants,
        summary: meeting.summary || undefined,
        transcript: meeting.transcript || undefined,
        meetingType: classification.meetingType,
      })

      // Save artifacts
      if (content.dealMemo) {
        await prisma.artifact.create({
          data: {
            workspaceId: this.workspaceId,
            meetingId,
            type: 'deal_memo',
            content: content.dealMemo,
          }
        })
      }

      if (content.followUp) {
        await prisma.artifact.create({
          data: {
            workspaceId: this.workspaceId,
            meetingId,
            type: 'follow_up',
            content: content.followUp,
          }
        })
      }

      await this.log(meetingId, 'generation', 'completed', 'Content generated')

      // Step 3: File to Google Drive
      if (workspace.autoFile) {
        await this.fileToGoogleDrive(meetingId)
      }

      // Mark complete
      await prisma.meeting.update({
        where: { id: meetingId },
        data: { status: 'completed', processedAt: new Date() }
      })
    } catch (error) {
      await prisma.meeting.update({
        where: { id: meetingId },
        data: { 
          status: 'failed',
          errorMessage: error instanceof Error ? error.message : 'Unknown error'
        }
      })
      await this.log(meetingId, 'processing', 'failed', error instanceof Error ? error.message : 'Unknown error')
    }
  }

  /**
   * File artifacts to Google Drive
   */
  private async fileToGoogleDrive(meetingId: string): Promise<void> {
    try {
      await this.log(meetingId, 'filing', 'started')

      // Get Drive token
      const driveAccount = await prisma.connectedAccount.findFirst({
        where: { workspaceId: this.workspaceId, provider: 'google_drive' }
      })

      if (!driveAccount?.accessToken) {
        await this.log(meetingId, 'filing', 'skipped', 'Google Drive not connected')
        return
      }

      // Get meeting and artifacts
      const meeting = await prisma.meeting.findUnique({
        where: { id: meetingId },
        include: { artifacts: { where: { isLatest: true } } }
      })

      if (!meeting) return

      const workspace = await prisma.workspace.findUnique({
        where: { id: this.workspaceId }
      })

      if (!workspace?.driveFolderId) {
        await this.log(meetingId, 'filing', 'skipped', 'Drive folders not configured')
        return
      }

      const drive = new GoogleDriveService(driveAccount.accessToken)

      // Determine target folder
      const folderMap: any = JSON.parse(workspace.driveFolderId || '{}')
      let targetFolder = folderMap.inbox

      if (meeting.meetingType === 'startup_pitch' && meeting.confidence && meeting.confidence >= workspace.confidenceThreshold) {
        targetFolder = folderMap.startupPitches
      } else if (meeting.meetingType === 'business_meeting') {
        targetFolder = folderMap.businessMeetings
      }

      // Create documents
      for (const artifact of meeting.artifacts) {
        const title = `${meeting.title} - ${artifact.type} - ${meeting.date.toISOString().split('T')[0]}`
        const doc = await drive.createDocument(title, artifact.content, targetFolder)

        await prisma.artifact.update({
          where: { id: artifact.id },
          data: {
            driveFileId: doc.id,
            driveUrl: doc.url,
            folderId: targetFolder,
          }
        })
      }

      await this.log(meetingId, 'filing', 'completed', 'Filed to Google Drive')
    } catch (error) {
      await this.log(meetingId, 'filing', 'failed', error instanceof Error ? error.message : 'Unknown error')
    }
  }

  /**
   * Log processing event
   */
  private async log(meetingId: string, stage: string, status: string, message?: string): Promise<void> {
    await prisma.processingLog.create({
      data: { meetingId, stage, status, message }
    })
  }
}
