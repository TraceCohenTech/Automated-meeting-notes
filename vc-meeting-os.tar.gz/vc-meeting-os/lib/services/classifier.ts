/**
 * Meeting Classification Engine
 * Analyzes meetings and categorizes them
 */

export interface ClassificationResult {
  meetingType: 'startup_pitch' | 'business_meeting' | 'other'
  confidence: number
  companyName?: string
  reasoning: string
}

export class MeetingClassifier {
  /**
   * Classify a meeting based on multiple signals
   */
  classify(meeting: {
    title: string
    participants: string[]
    summary?: string
    transcript?: string
  }): ClassificationResult {
    let score = 0
    let maxScore = 0
    const signals: string[] = []

    // Title analysis
    const titleLower = meeting.title.toLowerCase()
    const pitchKeywords = ['pitch', 'demo', 'startup', 'founder', 'fundraising', 'investment', 'hubble call']
    const businessKeywords = ['sync', 'standup', 'review', 'planning', 'update', 'lp', 'limited partner']

    maxScore += 3
    if (pitchKeywords.some(k => titleLower.includes(k))) {
      score += 3
      signals.push('Title contains pitch indicators')
    } else if (businessKeywords.some(k => titleLower.includes(k))) {
      score -= 1
    }

    // Participant analysis - check for external domains
    maxScore += 2
    const externalEmails = meeting.participants.filter(p => 
      !p.includes('@sixpoint.vc') && 
      !p.includes('@nyvp.com') &&
      p.includes('@')
    )
    if (externalEmails.length > 0) {
      score += 2
      signals.push(`${externalEmails.length} external participants`)
    }

    // Summary/transcript content analysis
    if (meeting.summary || meeting.transcript) {
      const content = `${meeting.summary || ''} ${meeting.transcript || ''}`.toLowerCase()
      const pitchContent = ['product', 'market', 'traction', 'revenue', 'funding', 'raise', 'valuation', 'round']
      const businessContent = ['portfolio', 'fund', 'diligence', 'legal', 'operations']

      maxScore += 2
      const pitchMatches = pitchContent.filter(k => content.includes(k)).length
      const businessMatches = businessContent.filter(k => content.includes(k)).length

      if (pitchMatches >= 3) {
        score += 2
        signals.push('Content suggests pitch discussion')
      } else if (businessMatches >= 2) {
        score -= 1
      }
    }

    // Extract company name
    let companyName: string | undefined
    const titleMatch = meeting.title.match(/^([A-Z][a-zA-Z0-9\s&]+)(?:\s+[-:<>\/]|\s+Call|\s+Demo)/i)
    if (titleMatch) {
      companyName = titleMatch[1].trim()
    }

    // Determine classification
    const confidence = Math.min(score / maxScore, 1.0)
    let meetingType: 'startup_pitch' | 'business_meeting' | 'other'

    if (confidence >= 0.6) {
      meetingType = 'startup_pitch'
    } else if (businessKeywords.some(k => titleLower.includes(k))) {
      meetingType = 'business_meeting'
    } else {
      meetingType = 'other'
    }

    return {
      meetingType,
      confidence,
      companyName,
      reasoning: signals.join('; ')
    }
  }
}
