/**
 * Google Drive Service
 * Handles folder creation and document filing
 */

import { google } from 'googleapis'

export class GoogleDriveService {
  private drive: any
  private docs: any

  constructor(accessToken: string) {
    const auth = new google.auth.OAuth2()
    auth.setCredentials({ access_token: accessToken })
    
    this.drive = google.drive({ version: 'v3', auth })
    this.docs = google.docs({ version: 'v1', auth })
  }

  /**
   * Create folder structure for VC Meeting OS
   */
  async createFolderStructure(parentFolderId?: string): Promise<{ [key: string]: string }> {
    const rootFolder = await this.createFolder('VC Meeting OS', parentFolderId)
    
    const folders = await Promise.all([
      this.createFolder('01 Startup Pitches', rootFolder),
      this.createFolder('02 Business Meetings', rootFolder),
      this.createFolder('03 Other', rootFolder),
      this.createFolder('99 Inbox (Unclassified)', rootFolder),
      this.createFolder('Templates', rootFolder),
    ])

    return {
      root: rootFolder,
      startupPitches: folders[0],
      businessMeetings: folders[1],
      other: folders[2],
      inbox: folders[3],
      templates: folders[4],
    }
  }

  /**
   * Create a folder (idempotent)
   */
  async createFolder(name: string, parentId?: string): Promise<string> {
    try {
      // Check if folder exists
      const query = parentId 
        ? `name='${name}' and '${parentId}' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false`
        : `name='${name}' and mimeType='application/vnd.google-apps.folder' and trashed=false`
      
      const existing = await this.drive.files.list({
        q: query,
        fields: 'files(id, name)',
        spaces: 'drive',
      })

      if (existing.data.files && existing.data.files.length > 0) {
        return existing.data.files[0].id
      }

      // Create new folder
      const fileMetadata: any = {
        name,
        mimeType: 'application/vnd.google-apps.folder',
      }
      
      if (parentId) {
        fileMetadata.parents = [parentId]
      }

      const file = await this.drive.files.create({
        resource: fileMetadata,
        fields: 'id',
      })

      return file.data.id
    } catch (error) {
      console.error('Error creating folder:', error)
      throw error
    }
  }

  /**
   * Create a Google Doc with content
   */
  async createDocument(
    title: string,
    content: string,
    folderId: string
  ): Promise<{ id: string; url: string }> {
    try {
      // Create document
      const doc = await this.docs.documents.create({
        requestBody: { title },
      })

      const documentId = doc.data.documentId

      // Insert content
      await this.docs.documents.batchUpdate({
        documentId,
        requestBody: {
          requests: [
            {
              insertText: {
                location: { index: 1 },
                text: content,
              },
            },
          ],
        },
      })

      // Move to folder
      await this.drive.files.update({
        fileId: documentId,
        addParents: folderId,
        fields: 'id, parents',
      })

      const url = `https://docs.google.com/document/d/${documentId}/edit`

      return { id: documentId, url }
    } catch (error) {
      console.error('Error creating document:', error)
      throw error
    }
  }

  /**
   * Update existing document
   */
  async updateDocument(documentId: string, content: string): Promise<void> {
    try {
      // Get current content length
      const doc = await this.docs.documents.get({ documentId })
      const endIndex = doc.data.body.content[doc.data.body.content.length - 1].endIndex

      // Replace all content
      await this.docs.documents.batchUpdate({
        documentId,
        requestBody: {
          requests: [
            {
              deleteContentRange: {
                range: {
                  startIndex: 1,
                  endIndex: endIndex - 1,
                },
              },
            },
            {
              insertText: {
                location: { index: 1 },
                text: content,
              },
            },
          ],
        },
      })
    } catch (error) {
      console.error('Error updating document:', error)
      throw error
    }
  }
}
