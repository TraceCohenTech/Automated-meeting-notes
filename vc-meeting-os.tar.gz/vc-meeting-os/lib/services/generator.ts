/**
 * AI Content Generation Service
 * Generates deal memos, follow-ups, and action items
 */

export interface GeneratedContent {
  dealMemo?: string
  followUp?: string
  actionItems?: string
  founderEmail?: string
  summary?: string
}

export class ContentGenerator {
  /**
   * Generate all content for a meeting
   */
  async generate(meeting: {
    title: string
    date: Date
    duration: number
    participants: string[]
    summary?: string
    transcript?: string
    meetingType: string
  }): Promise<GeneratedContent> {
    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 4000,
          messages: [{
            role: "user",
            content: this.buildPrompt(meeting)
          }]
        })
      })

      const data = await response.json()
      return this.parseResponse(data, meeting.meetingType)
    } catch (error) {
      console.error("Error generating content:", error)
      return {}
    }
  }

  private buildPrompt(meeting: any): string {
    if (meeting.meetingType === 'startup_pitch') {
      return `Analyze this startup pitch meeting and create a comprehensive deal memo.

Meeting: ${meeting.title}
Date: ${meeting.date}
Duration: ${meeting.duration} minutes
Participants: ${meeting.participants.join(', ')}
Summary: ${meeting.summary || 'N/A'}

Create a professional deal memo with these sections:
1. Executive Summary (2-3 sentences)
2. Company Overview
3. Team & Founders
4. Product & Technology
5. Market Opportunity
6. Business Model
7. Traction & Metrics
8. Competition
9. Investment Terms (if mentioned)
10. Risks & Concerns
11. Action Items
12. Recommendation Framework

Format as clean, skimmable markdown. Be analytical and neutral. Extract key data points.`
    } else {
      return `Analyze this business meeting and create a follow-up document.

Meeting: ${meeting.title}
Date: ${meeting.date}
Duration: ${meeting.duration} minutes
Summary: ${meeting.summary || 'N/A'}

Create a professional meeting brief with:
1. Meeting Summary (2-3 sentences)
2. Key Discussion Points (3-5 bullets)
3. Action Items (with owners if identifiable)
4. Next Steps
5. Strategic Takeaways

Format as clean, skimmable markdown. Be concise and actionable.`
    }
  }

  private parseResponse(data: any, meetingType: string): GeneratedContent {
    const textContent = data.content
      ?.filter((item: any) => item.type === "text")
      .map((item: any) => item.text)
      .join("\n") || ""

    if (meetingType === 'startup_pitch') {
      return {
        dealMemo: textContent,
        summary: this.extractSection(textContent, 'Executive Summary')
      }
    } else {
      return {
        followUp: textContent,
        actionItems: this.extractSection(textContent, 'Action Items'),
        summary: this.extractSection(textContent, 'Meeting Summary')
      }
    }
  }

  private extractSection(content: string, sectionName: string): string {
    const regex = new RegExp(`##?\\s*${sectionName}[\\s\\S]*?(?=##|$)`, 'i')
    const match = content.match(regex)
    return match ? match[0].replace(/##?\s*${sectionName}/i, '').trim() : ''
  }
}
