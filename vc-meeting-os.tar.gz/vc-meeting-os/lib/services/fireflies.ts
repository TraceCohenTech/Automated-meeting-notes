/**
 * Fireflies API Integration
 * Handles meeting fetching and transcript retrieval
 */

export interface FirefliesMeeting {
  id: string
  title: string
  date: string
  duration: number
  organizer?: string
  participants: string[]
  transcript?: string
  summary?: string
  keywords?: string[]
  actionItems?: string
}

export class FirefliesService {
  private accessToken: string

  constructor(accessToken: string) {
    this.accessToken = accessToken
  }

  /**
   * Fetch recent meetings using Claude's MCP integration
   */
  async fetchRecentMeetings(limit: number = 20): Promise<FirefliesMeeting[]> {
    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 4000,
          mcp_servers: [{
            type: "url",
            url: "https://api.fireflies.ai/mcp",
            name: "fireflies-mcp"
          }],
          messages: [{
            role: "user",
            content: `Use fireflies_get_transcripts to get the last ${limit} meetings. Return structured data.`
          }]
        })
      })

      const data = await response.json()
      return this.parseMeetingsFromResponse(data)
    } catch (error) {
      console.error("Error fetching meetings:", error)
      return []
    }
  }

  /**
   * Get full meeting details including transcript
   */
  async getMeetingDetails(meetingId: string): Promise<FirefliesMeeting | null> {
    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 4000,
          mcp_servers: [{
            type: "url",
            url: "https://api.fireflies.ai/mcp",
            name: "fireflies-mcp"
          }],
          messages: [{
            role: "user",
            content: `Use fireflies_fetch to get full details for meeting ID: ${meetingId}`
          }]
        })
      })

      const data = await response.json()
      const meetings = this.parseMeetingsFromResponse(data)
      return meetings[0] || null
    } catch (error) {
      console.error("Error fetching meeting details:", error)
      return null
    }
  }

  /**
   * Parse meetings from API response
   */
  private parseMeetingsFromResponse(data: any): FirefliesMeeting[] {
    const meetings: FirefliesMeeting[] = []
    
    try {
      const toolResults = data.content
        ?.filter((item: any) => item.type === "mcp_tool_result")
        .map((item: any) => item.content?.[0]?.text || "")
        .join("\n") || ""

      const lines = toolResults.split('\n')
      let current: any = null

      for (const line of lines) {
        if (line.includes('- id:')) {
          if (current) meetings.push(current)
          current = {
            id: this.extractValue(line, 'id'),
            participants: [],
            keywords: []
          }
        } else if (current) {
          if (line.includes('title:')) current.title = this.extractValue(line, 'title')
          if (line.includes('dateString:')) current.date = this.extractValue(line, 'dateString')
          if (line.includes('duration:')) current.duration = parseInt(this.extractValue(line, 'duration'))
          if (line.includes('organizer_email:')) current.organizer = this.extractValue(line, 'organizer_email')
          if (line.includes('short_summary:')) current.summary = this.extractValue(line, 'short_summary')
        }
      }
      
      if (current) meetings.push(current)
    } catch (error) {
      console.error("Error parsing meetings:", error)
    }

    return meetings.filter(m => m.id && m.title)
  }

  private extractValue(line: string, field: string): string {
    const match = line.match(new RegExp(`${field}:\\s*"?([^"\\n]+)"?`))
    return match ? match[1].trim().replace(/"/g, '') : ''
  }
}
