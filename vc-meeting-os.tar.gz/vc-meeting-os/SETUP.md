# VC Meeting OS - Complete Setup Guide

## Local Development Setup (15 minutes)

### Prerequisites
- Node.js 18+ installed
- PostgreSQL 14+ running locally
- Git

### Step-by-Step Setup

#### 1. Clone and Install
```bash
cd vc-meeting-os

# Install dependencies
npm install

# This will also run `prisma generate` via postinstall
```

#### 2. Configure Environment
```bash
# Copy example env file
cp .env.example .env.local

# Edit .env.local with your values
nano .env.local
```

**Required values**:
```bash
DATABASE_URL="postgresql://postgres:password@localhost:5432/vc_meeting_os"
NEXTAUTH_SECRET="run: openssl rand -base64 32"
NEXTAUTH_URL="http://localhost:3000"
ANTHROPIC_API_KEY="your-key-here"
```

#### 3. Setup Database
```bash
# Create database
createdb vc_meeting_os

# Run migrations
npx prisma migrate dev

# (Optional) Seed with sample data
npx prisma db seed
```

#### 4. Start Development Server
```bash
npm run dev

# Open http://localhost:3000
```

#### 5. Create First User
1. Go to http://localhost:3000/signup
2. Enter email and password
3. Enter workspace name (e.g., "Acme Ventures")
4. Click "Create Account"

You're now ready to develop!

## Project Structure

```
vc-meeting-os/
├── app/                    # Next.js App Router
│   ├── page.tsx           # Landing page
│   ├── login/             # Authentication pages
│   ├── signup/
│   ├── dashboard/         # Main app dashboard
│   ├── api/               # API routes
│   │   ├── auth/         # NextAuth endpoints
│   │   ├── meetings/     # Meeting CRUD
│   │   ├── integrations/ # OAuth flows
│   │   └── cron/         # Scheduled jobs
│   └── layout.tsx         # Root layout
│
├── lib/                    # Core business logic
│   ├── services/          # Service layer
│   │   ├── pipeline.ts   # Main processing pipeline
│   │   ├── fireflies.ts  # Fireflies API
│   │   ├── classifier.ts # Meeting classification
│   │   ├── generator.ts  # AI content generation
│   │   └── drive.ts      # Google Drive API
│   ├── auth.ts           # NextAuth config
│   ├── prisma.ts         # Database client
│   └── utils.ts          # Utilities
│
├── components/            # React components
│   ├── auth/             # Auth forms
│   ├── dashboard/        # Dashboard components
│   └── ui/               # Reusable UI components
│
├── prisma/
│   └── schema.prisma     # Database schema
│
├── public/               # Static assets
│
├── README.md            # Overview
├── ARCHITECTURE.md      # Technical docs
├── DEPLOYMENT.md        # Deploy guide
└── SETUP.md             # This file
```

## Key Files Explained

### Database Schema (`prisma/schema.prisma`)
Defines all data models:
- Workspace (tenant)
- User (authentication)
- Meeting (from Fireflies)
- Artifact (generated content)
- ConnectedAccount (OAuth tokens)
- ProcessingLog (audit trail)

### Pipeline (`lib/services/pipeline.ts`)
Orchestrates the entire meeting processing flow:
1. Fetch from Fireflies
2. Classify meeting type
3. Generate content with AI
4. File to Google Drive
5. Update database status

### Classification (`lib/services/classifier.ts`)
Analyzes meetings using:
- Title keywords
- Participant domains
- Content analysis
- Returns confidence score and type

### Generator (`lib/services/generator.ts`)
Creates two types of documents:
- **Deal Memos**: For startup pitches
- **Follow-ups**: For business meetings

### Drive Service (`lib/services/drive.ts`)
Handles Google Drive operations:
- Create folder structure
- Upload documents
- Update existing docs

## Development Workflow

### Making Changes

1. **Database Changes**
```bash
# Edit prisma/schema.prisma
# Then create migration
npx prisma migrate dev --name add_new_field

# Update Prisma client
npx prisma generate
```

2. **Add New Service**
```bash
# Create file in lib/services/
touch lib/services/my-service.ts

# Import in pipeline
# Test with sample data
```

3. **Add New Page**
```bash
# Create in app/
mkdir -p app/my-page
touch app/my-page/page.tsx

# Define as Server or Client Component
```

### Testing

```bash
# Run type checking
npx tsc --noEmit

# Run linter
npm run lint

# Test database connection
npx prisma studio
```

### Debugging

**View logs**:
```bash
# Development logs in terminal

# Database queries (if enabled)
# See prisma client logs in console
```

**Inspect data**:
```bash
# Open Prisma Studio
npx prisma studio

# Browse at http://localhost:5555
```

**Test OAuth flows**:
1. Setup ngrok for local HTTPS
2. Update OAuth callback URLs
3. Test connect/disconnect flows

## Common Development Tasks

### Add New Meeting Classification Rule
Edit `lib/services/classifier.ts`:
```typescript
const pitchKeywords = ['pitch', 'demo', 'your-new-keyword']
```

### Customize AI Prompts
Edit `lib/services/generator.ts`:
```typescript
private buildPrompt(meeting: any): string {
  // Modify prompt template
}
```

### Add New Artifact Type
1. Update Prisma schema
2. Add generation logic in generator
3. Update dashboard to display

### Configure Auto-Sync Frequency
Edit `vercel.json`:
```json
{
  "crons": [{
    "path": "/api/cron/ingest",
    "schedule": "*/5 * * * *"  // Every 5 minutes
  }]
}
```

## Environment Variables Explained

| Variable | Purpose | Where to Get |
|----------|---------|--------------|
| `DATABASE_URL` | PostgreSQL connection | Local: `postgresql://postgres:password@localhost:5432/db` |
| `NEXTAUTH_SECRET` | Session encryption | Generate: `openssl rand -base64 32` |
| `NEXTAUTH_URL` | App URL | Local: `http://localhost:3000` |
| `ANTHROPIC_API_KEY` | Claude AI access | https://console.anthropic.com |
| `GOOGLE_CLIENT_ID` | Drive OAuth | Google Cloud Console |
| `GOOGLE_CLIENT_SECRET` | Drive OAuth | Google Cloud Console |
| `FIREFLIES_CLIENT_ID` | Meeting access | Contact Fireflies |
| `FIREFLIES_CLIENT_SECRET` | Meeting access | Contact Fireflies |

## Troubleshooting

### "Module not found" errors
```bash
rm -rf node_modules package-lock.json
npm install
```

### "Prisma Client not generated"
```bash
npx prisma generate
```

### "Database connection failed"
```bash
# Check PostgreSQL is running
pg_isready

# Verify DATABASE_URL
echo $DATABASE_URL
```

### "OAuth redirect URI mismatch"
- Ensure callback URLs match in OAuth app settings
- Check `NEXTAUTH_URL` is correct
- For local dev, use ngrok for HTTPS

### "API rate limit exceeded"
- Anthropic: Check usage at console.anthropic.com
- Google: Check quotas in Cloud Console
- Fireflies: Contact support for limits

## Next Steps

Once local development is working:

1. ✅ Test full pipeline with sample meeting
2. ✅ Verify document creation in Google Drive
3. ✅ Review generated content quality
4. 📝 Customize prompts for your use case
5. 🚀 Deploy to Vercel (see DEPLOYMENT.md)

## Getting Help

**Documentation**:
- README.md - Project overview
- ARCHITECTURE.md - Technical details
- DEPLOYMENT.md - Production setup

**Resources**:
- Next.js Docs: https://nextjs.org/docs
- Prisma Docs: https://prisma.io/docs
- NextAuth Docs: https://next-auth.js.org

**Common Issues**:
- Check Vercel logs for production
- Review processing logs in database
- Test OAuth connections individually
