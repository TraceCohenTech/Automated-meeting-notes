"use client";

import { useEffect, useState } from "react";
import { FileText, FolderSync, RefreshCw, Settings, LogOut } from "lucide-react";

export default function DashboardPage() {
  const [stats, setStats] = useState({
    total: 0,
    processed: 0,
    pending: 0,
    today: 0,
  });
  
  const [meetings, setMeetings] = useState([]);
  const [integrations, setIntegrations] = useState({
    fireflies: false,
    googleDrive: false,
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const response = await fetch('/api/dashboard/stats');
      const data = await response.json();
      setStats(data.stats);
      setMeetings(data.meetings);
      setIntegrations(data.integrations);
    } catch (error) {
      console.error('Error loading dashboard:', error);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-semibold text-slate-900">VC Meeting OS</span>
            </div>
            
            <div className="flex items-center gap-4">
              <button className="p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100">
                <Settings className="w-5 h-5" />
              </button>
              <button className="p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Integration Status */}
        <div className="bg-white rounded-xl p-6 border border-slate-200 mb-8">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">Integrations</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div className={`flex items-center justify-between p-4 rounded-lg border ${
              integrations.fireflies ? 'bg-green-50 border-green-200' : 'bg-slate-50 border-slate-200'
            }`}>
              <div>
                <div className="font-medium text-slate-900">Fireflies</div>
                <div className="text-sm text-slate-600">
                  {integrations.fireflies ? 'Connected' : 'Not connected'}
                </div>
              </div>
              {!integrations.fireflies && (
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium">
                  Connect
                </button>
              )}
            </div>
            
            <div className={`flex items-center justify-between p-4 rounded-lg border ${
              integrations.googleDrive ? 'bg-green-50 border-green-200' : 'bg-slate-50 border-slate-200'
            }`}>
              <div>
                <div className="font-medium text-slate-900">Google Drive</div>
                <div className="text-sm text-slate-600">
                  {integrations.googleDrive ? 'Connected' : 'Not connected'}
                </div>
              </div>
              {!integrations.googleDrive && (
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium">
                  Connect
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl p-6 border border-slate-200">
            <div className="text-3xl font-bold text-slate-900 mb-1">{stats.total}</div>
            <div className="text-sm text-slate-600">Total Meetings</div>
          </div>
          <div className="bg-white rounded-xl p-6 border border-slate-200">
            <div className="text-3xl font-bold text-green-600 mb-1">{stats.processed}</div>
            <div className="text-sm text-slate-600">Processed</div>
          </div>
          <div className="bg-white rounded-xl p-6 border border-slate-200">
            <div className="text-3xl font-bold text-yellow-600 mb-1">{stats.pending}</div>
            <div className="text-sm text-slate-600">Pending</div>
          </div>
          <div className="bg-white rounded-xl p-6 border border-slate-200">
            <div className="text-3xl font-bold text-blue-600 mb-1">{stats.today}</div>
            <div className="text-sm text-slate-600">Today</div>
          </div>
        </div>

        {/* Meetings List */}
        <div className="bg-white rounded-xl border border-slate-200">
          <div className="p-6 border-b border-slate-200 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-slate-900">Recent Meetings</h2>
            <button 
              onClick={loadData}
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 hover:text-slate-900 rounded-lg hover:bg-slate-100"
            >
              <RefreshCw className="w-4 h-4" />
              Refresh
            </button>
          </div>
          
          <div className="divide-y divide-slate-200">
            {meetings.length === 0 ? (
              <div className="p-12 text-center">
                <FolderSync className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <p className="text-slate-600">No meetings yet</p>
                <p className="text-sm text-slate-500 mt-2">Connect Fireflies to start ingesting meetings</p>
              </div>
            ) : (
              meetings.map((meeting: any) => (
                <div key={meeting.id} className="p-6 hover:bg-slate-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-medium text-slate-900 mb-1">{meeting.title}</h3>
                      <div className="flex items-center gap-4 text-sm text-slate-600">
                        <span>{new Date(meeting.date).toLocaleDateString()}</span>
                        <span>{meeting.duration} min</span>
                        <span className="capitalize">{meeting.meetingType.replace('_', ' ').toLowerCase()}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {meeting.isProcessed ? (
                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                          Processed
                        </span>
                      ) : (
                        <span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-sm font-medium">
                          Pending
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
