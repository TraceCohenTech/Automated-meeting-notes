import Link from 'next/link'
import { ArrowRight, CheckCircle2, Shield, Zap, FileText, Users, Bot } from 'lucide-react'

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-semibold">VC Meeting OS</span>
          </div>
          <Link 
            href="/login"
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Get Started
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="container mx-auto px-4 py-20 md:py-32">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
            Turn meeting transcripts into
            <span className="block text-blue-600 mt-2">professional deal memos</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Automatically process Fireflies meetings, classify startup pitches, and generate
            partner-ready deal memos filed directly to Google Drive.
          </p>
          <Link 
            href="/signup"
            className="inline-flex items-center gap-2 px-8 py-4 bg-blue-600 text-white text-lg rounded-lg hover:bg-blue-700 transition-colors"
          >
            Start Free Trial
            <ArrowRight className="h-5 w-5" />
          </Link>
          <p className="text-sm text-gray-500 mt-4">No credit card required</p>
        </div>
      </section>

      {/* How It Works */}
      <section className="container mx-auto px-4 py-20 border-t">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-4">How it works</h2>
          <p className="text-center text-gray-600 mb-12">Three steps to automated deal flow</p>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-lg font-semibold">
                1
              </div>
              <h3 className="font-semibold text-lg mb-2">Connect</h3>
              <p className="text-gray-600">
                Link Fireflies and Google Drive with secure OAuth. One-time setup.
              </p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-lg font-semibold">
                2
              </div>
              <h3 className="font-semibold text-lg mb-2">Automatic Processing</h3>
              <p className="text-gray-600">
                New meetings are classified, analyzed, and transformed into structured documents.
              </p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-lg font-semibold">
                3
              </div>
              <h3 className="font-semibold text-lg mb-2">Filed & Ready</h3>
              <p className="text-gray-600">
                Docs appear in organized Drive folders, ready for partner review.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Output Types */}
      <section className="container mx-auto px-4 py-20 border-t bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Meeting-specific outputs</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg border">
              <Zap className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="font-semibold text-xl mb-2">Startup Pitch → Deal Memo</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Executive summary</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Team & founder analysis</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Market opportunity assessment</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Investment thesis framework</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Risks & due diligence items</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-lg border">
              <Users className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="font-semibold text-xl mb-2">Business Meeting → Brief</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Meeting summary</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Key discussion points</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Action items with owners</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Next steps</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>Strategic takeaways</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Security */}
      <section className="container mx-auto px-4 py-20 border-t">
        <div className="max-w-4xl mx-auto text-center">
          <Shield className="h-12 w-12 text-blue-600 mx-auto mb-6" />
          <h2 className="text-3xl font-bold mb-4">Secure & Private</h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Your meeting data never leaves your systems. We use secure OAuth tokens,
            process everything in real-time, and never store transcripts permanently.
          </p>
          <div className="grid md:grid-cols-3 gap-8 text-left">
            <div>
              <h3 className="font-semibold mb-2">Encrypted Tokens</h3>
              <p className="text-sm text-gray-600">
                OAuth tokens stored with industry-standard encryption
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">No Data Retention</h3>
              <p className="text-sm text-gray-600">
                Transcripts processed on-demand, not stored long-term
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Your Drive, Your Control</h3>
              <p className="text-sm text-gray-600">
                All documents saved directly to your Google Drive
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-4 py-20 border-t">
        <div className="max-w-2xl mx-auto text-center bg-blue-600 text-white rounded-2xl p-12">
          <h2 className="text-3xl font-bold mb-4">Ready to automate your deal flow?</h2>
          <p className="text-lg mb-8 text-blue-100">
            Join VCs who are already saving hours per week on meeting documentation.
          </p>
          <Link 
            href="/signup"
            className="inline-flex items-center gap-2 px-8 py-4 bg-white text-blue-600 text-lg rounded-lg hover:bg-gray-100 transition-colors"
          >
            Get Started Free
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-gray-50">
        <div className="container mx-auto px-4 py-8 text-center text-gray-600">
          <p>© 2026 VC Meeting OS. Built for venture capitalists.</p>
        </div>
      </footer>
    </div>
  )
}
