import NextAuth, { NextAuthOptions } from "next-auth";
import { PrismaAdapter } from "@auth/prisma-adapter";
import { prisma } from "@/lib/prisma";
import EmailProvider from "next-auth/providers/email";

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma) as any,
  providers: [
    EmailProvider({
      server: {
        host: process.env.EMAIL_SERVER_HOST,
        port: process.env.EMAIL_SERVER_PORT,
        auth: {
          user: process.env.EMAIL_SERVER_USER,
          pass: process.env.EMAIL_SERVER_PASSWORD,
        },
      },
      from: process.env.EMAIL_FROM,
    }),
  ],
  pages: {
    signIn: "/auth/signin",
    verifyRequest: "/auth/verify",
    error: "/auth/error",
  },
  callbacks: {
    async session({ session, user }) {
      if (session.user) {
        session.user.id = user.id;
        // Fetch workspace
        const dbUser = await prisma.user.findUnique({
          where: { id: user.id },
          include: { workspace: true },
        });
        if (dbUser) {
          session.user.workspaceId = dbUser.workspaceId;
          session.user.workspace = dbUser.workspace;
        }
      }
      return session;
    },
  },
  events: {
    async createUser({ user }) {
      // Create a default workspace for new users
      const workspace = await prisma.workspace.create({
        data: {
          name: user.email?.split("@")[0] + "'s Workspace",
          slug: user.id.slice(0, 12),
        },
      });

      // Link user to workspace
      await prisma.user.update({
        where: { id: user.id },
        data: { workspaceId: workspace.id },
      });

      // Create default settings
      await prisma.workspaceSettings.create({
        data: {
          workspaceId: workspace.id,
        },
      });
    },
  },
};

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };
