import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.workspaceId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const workspaceId = session.user.workspaceId;

    // Get stats
    const [total, processed, today] = await Promise.all([
      prisma.meeting.count({ where: { workspaceId } }),
      prisma.meeting.count({ where: { workspaceId, isProcessed: true } }),
      prisma.meeting.count({
        where: {
          workspaceId,
          createdAt: {
            gte: new Date(new Date().setHours(0, 0, 0, 0)),
          },
        },
      }),
    ]);

    const pending = total - processed;

    // Get recent meetings
    const meetings = await prisma.meeting.findMany({
      where: { workspaceId },
      orderBy: { date: 'desc' },
      take: 20,
      select: {
        id: true,
        title: true,
        date: true,
        duration: true,
        meetingType: true,
        isProcessed: true,
        inferredCompany: true,
      },
    });

    // Get integration status
    const integrations = await prisma.connectedAccount.findMany({
      where: { workspaceId },
      select: { provider: true, isActive: true },
    });

    const integrationsStatus = {
      fireflies: integrations.some(i => i.provider === 'fireflies' && i.isActive),
      googleDrive: integrations.some(i => i.provider === 'google_drive' && i.isActive),
    };

    return NextResponse.json({
      stats: { total, processed, pending, today },
      meetings,
      integrations: integrationsStatus,
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
