import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { ProcessingPipeline } from "@/lib/processing-pipeline";

export async function GET(request: Request) {
  try {
    // Verify cron secret
    const authHeader = request.headers.get('authorization');
    if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    console.log('[CRON] Starting meeting processing...');

    // Get all active workspaces
    const workspaces = await prisma.workspace.findMany({
      where: {
        connectedAccounts: {
          some: {
            provider: 'fireflies',
            isActive: true,
          },
        },
      },
    });

    let totalIngested = 0;
    let totalProcessed = 0;

    for (const workspace of workspaces) {
      try {
        const pipeline = new ProcessingPipeline(workspace.id);
        
        // Ingest new meetings
        const ingested = await pipeline.ingestMeetings();
        totalIngested += ingested;
        console.log(`[CRON] Workspace ${workspace.id}: Ingested ${ingested} meetings`);

        // Process pending meetings
        const pendingMeetings = await prisma.meeting.findMany({
          where: {
            workspaceId: workspace.id,
            isProcessed: false,
          },
          take: 10, // Process in batches
        });

        for (const meeting of pendingMeetings) {
          try {
            await pipeline.processMeeting(meeting.id);
            totalProcessed++;
            console.log(`[CRON] Processed meeting: ${meeting.id}`);
          } catch (error) {
            console.error(`[CRON] Error processing meeting ${meeting.id}:`, error);
          }
        }
      } catch (error) {
        console.error(`[CRON] Error processing workspace ${workspace.id}:`, error);
      }
    }

    console.log(`[CRON] Complete: Ingested ${totalIngested}, Processed ${totalProcessed}`);

    return NextResponse.json({
      success: true,
      ingested: totalIngested,
      processed: totalProcessed,
    });
  } catch (error: any) {
    console.error('[CRON] Error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
